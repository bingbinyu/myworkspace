#!/bin/bash

touch test-empty.mp3
dd if=/dev/urandom of=test-random.mp3 bs=1M count=2

printf "\n\n\n"

./aufgabe1.sh test-empty.mp3 > tmp.txt
head=$(head -c 4 tmp.txt)
if [ $head=="File" ]
then
    echo "Empty file test was successful"
else
    echo "Empty file test was not successful"
fi
./aufgabe1.sh test-random.mp3 > tmp.txt
head=$(head -c 4 tmp.txt)
if [ $head=="File" ]
then
    echo "Random file test was successful"
else
    echo "Radnom file test was not successful"
fi
tmp=$(./aufgabe1.sh -test aufgabe1/track1.mp3 | tail -c 66)
if [ $tmp == "J._Postel_&_The_Packet_Drops-Source_Quench-Fragments_of_IP-01.mp3" ]
then
    echo "Normal test was successful"
else
    echo "Normal test was successful"
fi
./aufgabe1.sh -test aufgabe1/* > tmp.txt
tmp=$(head -n 1 -c 4 tmp.txt)
if [ $head == "File" ]
then
    echo "File with spaces test was successful"
else
    echo "File with spaces test was not successful"
fi

rm test-empty.mp3
rm test-random.mp3
rm tmp.txt
