#!/bin/bash
current=undef

isTest=$false

function rename()
{
    fileExt=$(tail "$current" -c 128 | head -c 3)
    if [ "$fileExt" != "TAG" ]
    then
        echo "File is supported not:" "$current"
        return
    fi
    title=$(tail "$current" -c 125 | head -c 30 | tr ' ' _)
    artist=$(tail "$current" -c 95  | head -c 30 | tr ' ' _)
    album=$(tail "$current" -c 65  | head -c 30 | tr ' ' _)
    tn=$(tail -c 3 "$current" | hexdump -ve '/1 "%02i "' | awk '{ if ($1 == 0 && $2 != 0) print $2 }';)
    # reiner Name
    nn=($artist"-"$album"-"$title"-"$tn)
    bn=$(basename "$current")
    tail=$(echo $bn | head -c-5)
    if [ $tail != ".mp3" ]
    then
        nn=$nn".mp3"
    fi
    nnn=${current//$bn/$nn}
    if [ "$isTest" != "$true" ]
    then
        #mv "$current" "$nnn"
        echo "Fail"
    else
        echo "Moving $current to $nnn"
    fi
}


if [ $# -eq 0 ]
then
    echo "No arguments given... Exiting now."
    exit -1
fi

for i in $*; do
    if [ $i == "-test" ]
    then
        isTest=$true
    else
        current="$i"
        rename
    fi
done

exit
