#!/usr/bin/env bash


# Mit der for Schleife iterieren wir über 
# die Datei-Argumente
for file in "$@"; do
	# Abfrage für den Track der sich an Bytestelle 4-30 befindet
    title=`tail -c 128 ${file} |cut -b4-30`
	# Wenn variable leer ist, setzen wir ein '_' wie in der Aufgabenstellung
	if [[ -z "$title" ]]; then
		title="_"
	fi
	# Abfrage für den Künstler der sich an Bytestelle 31-61 befindet
    artist=`tail -c 128 ${file} |cut -b31-61`
	if [[ -z "$artist" ]]; then
		artist="_"
	fi
	# Abfrage für das Album der sich an Bytestelle 62-92 befindet
	album=`tail -c 128 ${file} |cut -b62-92`
	if [[ -z "$album" ]]; then
		album="_"
	fi
	# Abfrage für den Track der sich an Bytestelle 93-97 befindet
	year=`tail -c 128 ${file} |cut -b93-97`
	if [[ -z "$year" ]]; then
		year="_"
	fi
	# In diesem Befehl lesen wir die letzten 2 Bytes aus und schneiden den ersten Byte raus an
	# dem sich die Tracknummer befindet. Diese wandeln wir in eine Dezimal zahl mit dem 'od'-Befehl
	# um und löschen die Leerzeichen. Zum Schluss schneiden wir das erste Byte wieder raus, da sich
	# dahinter nur noch eine 10 die das als Dezimalzahl repräsentieren lässt.
	track=`tail -c 2 ${file} | cut -b1-1 | od -An -vtu1 | tr -d " " | cut -b1-1`
	# Keine Tracknummer vorhanden? Dann gib 'NN' zurück
	if [[ "$track" == 0 ]]; then
		track="NN"
	fi
	# Kleiner als 10? Dann schieb eine 0 davor!
	if [[ "$track" -lt 10 ]]; then
		track="0$track"
	fi
	
	# Benenne Datei entsprechend der Aufgabenstellung um
	mv ${file} "${artist}-${album}-${title}-${track}.mp3"
done
