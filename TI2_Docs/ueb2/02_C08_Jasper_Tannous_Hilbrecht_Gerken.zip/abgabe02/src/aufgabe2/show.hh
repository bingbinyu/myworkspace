void show(unsigned long n);
