#include <iostream>

#include "show.hh"

void show(unsigned long n) {
  std::cout << n << ' ';
}

