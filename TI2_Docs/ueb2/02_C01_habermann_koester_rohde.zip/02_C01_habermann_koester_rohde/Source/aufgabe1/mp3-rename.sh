#!/bin/bash

##--forSchleife--##
for var in "$@"
    do
        # Is current param file or folder link?
        if [ -n "`echo $var | grep \"/\"`" ]; then
            folder="${var%%/*}/";
        else
            folder="";
        fi
##--forSchleife_end--##

##--extract--##
        # extract file's id3 tag information via ffprobe
        kuenstler=$(((ffprobe "$var" 2>&1 | sed -E -n 's/^ *artist *: (.*)/\1/p')|tr "-" _)|tr " " _);
        album=$(((ffprobe "$var" 2>&1 | sed -E -n 's/^ *album *: (.*)/\1/p')|tr "-" _)|tr " " _);
        titel=$(((ffprobe "$var" 2>&1 | sed -E -n 's/^ *title *: (.*)/\1/p')|tr "-" _)|tr " " _);
        track=$((ffprobe "$var" 2>&1 | sed -E -n 's/^ *track *: (.*)/\1/p')|cut -d"/" -f1);
##--extract_end--##

##--convert--##
        # convert track number to destination format
        if [ -z $track ]; then
            track="";
        else
                if [ $track -le "9" ]; then
                    track=-0$track;
                else
                        track=-$track;
                fi
        fi
##--convert_end--##

##--checkExtracted--##
        # check if extracted id3 tag information are empty - if yes: replace using underline
        if [ -z $kuenstler ]; then
                kuenstler="_";
        fi

        if [ -z $album ]; then
                album="_";
        fi

        if [ -z $titel ]; then
                titel="_";
        fi

        # move/rename files using extracted information
        # echo "DEBUG INFO: rename $var =====> $kuenstler-$album-$titel$track";
        mv "$var" "$folder$kuenstler-$album-$titel$track.mp3"
done
##--checkExtracted_end--##
