huhu maedels,
ich habe hier schon was gebastelt und die datei entsprechend mp3-rename.flo.sh genannt :-)
Funktioniert soweit ganz gut.

Für euch interessant: Der Ordner "original" ist read-only und gehört nicht zum Projekt. Wenn Ihr arbeitet,
könnt ihr euer Programm problemlos in diesem Ordner (aufgabe1) testen und danach "./reset.sh" ausführen.
Es werden dann alle .mp3's gelöscht und wieder durch die Originaldateien aus "original" ersetzt. 
Damit könnt ihr also wieder den Ursprungszustand herstellen, wenn euer Programm z.B. die Umbenennung nicht
richtig machen sollte. Viel Spass :-)
