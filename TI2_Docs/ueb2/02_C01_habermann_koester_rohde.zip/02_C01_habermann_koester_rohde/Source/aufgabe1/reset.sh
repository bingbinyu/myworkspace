echo "Loesche alle MP3s...."
rm *.mp3 2>/dev/null
rm the\ programmer/*.mp3>/dev/null
rm unknown 2> /dev/null
rm "the programmer/*.mp3" 2> /dev/null

echo "Kopiere die Original-Dateien wieder her..."
cp -R original/* . 2> /dev/null

echo "Erfolgreich aufgeraeumt :-)"

ls -la

